/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_unmatch.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchant <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/24 12:26:29 by lchant            #+#    #+#             */
/*   Updated: 2017/02/24 12:26:31 by lchant           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_pairing(int *tab, int length)
{
	int i;

	i = 0;
	while (i < length)
	{
		if (tab[i] != tab[i + 1])
			return (tab[i]);
		i = i + 2;
	}
	return (0);
}

int	ft_unmatched(int *tab, int length)
{
	int	i;
	int	j;
	int	temp;

	i = 0;
	j = 0;
	while (i < length)
	{
		while (j < length - 1 - i)
		{
			if (tab[j] > tab[j + 1])
			{
				temp = tab[j];
				tab[j] = tab[j + 1];
				tab[j + 1] = temp;
			}
			j++;
		}
		j = 0;
		i++;
	}
	return (ft_pairing(tab, length));
}
