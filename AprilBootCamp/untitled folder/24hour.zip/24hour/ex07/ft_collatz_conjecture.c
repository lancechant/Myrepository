/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_collatz_conjecture.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchant <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/23 22:02:16 by lchant            #+#    #+#             */
/*   Updated: 2017/02/23 22:04:13 by lchant           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_collatz_conjecture(unsigned int base)
{
	static int i = 0;

	if (base == 1)
		return (0);
	else if (base % 2 == 0)
		base = base / 2;
	else
		base = base * 3 + 1;
	i++;
	return (ft_collatz_conjecture(base));
}
