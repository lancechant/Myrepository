/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimator.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchant <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/23 21:09:25 by lchant            #+#    #+#             */
/*   Updated: 2017/02/23 21:11:00 by lchant           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# fndef __FT_ULTIMATOR_H__
# define __FT_ULTIMATOR_H__

/*
 * **
 * ** With Windows VISTA, we were on the edge of the abyss.
 * ** With Windows 8, we made a huge step forward.
 * **
 * ** The Client: 'I have a computer running on Windows 8'
 * ** The Technician: 'Yes...'
 * ** The Client: 'And it doesn't work anymore'
 * ** The Technician: 'Yeah, you already said...'
 * **
 * */

#endif
