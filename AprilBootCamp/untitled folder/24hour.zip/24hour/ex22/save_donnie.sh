mv donnie.txt donnie.bak
trap "mv donnie.bak donnie.txt" EXIT
