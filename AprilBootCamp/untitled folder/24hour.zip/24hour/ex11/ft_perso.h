/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_perso.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchant <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/24 02:02:41 by lchant            #+#    #+#             */
/*   Updated: 2017/02/24 02:31:43 by lchant           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PERSO_H

# define FT_PERSO_H

# include <string.h>

typedef struct	s_perso
{
	char	*name;
	float	life;
	int		age;
	void	*profession;
}				t_perso;

# define SAVE_AUSTIN_POWERS "groovy baby"

#endif
