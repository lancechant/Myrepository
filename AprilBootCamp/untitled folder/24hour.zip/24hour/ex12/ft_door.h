/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_door.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchant <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/24 03:45:10 by lchant            #+#    #+#             */
/*   Updated: 2017/02/24 03:45:13 by lchant           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_DOOR_H
# define FT_DOOR_H

# include <unistd.h>

# define TRUE 1

# define OPEN 1
# define CLOSE 0
# define FALSE 0
# define EXIT_SUCCESS 0

typedef int		t_bool;

typedef	struct	s_door
{
	int state;
}				t_door;

t_bool			open_door(t_door *door);
t_bool			close_door(t_door *door);
t_bool			is_door_open(t_door *door);
t_bool			is_door_closed(t_door *door);

#endif
